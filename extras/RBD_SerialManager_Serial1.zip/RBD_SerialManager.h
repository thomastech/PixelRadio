// Arduino RBD Serial Manager Library v1.0.0 - A simple interface for serial communication.
// https://github.com/alextaujenis/RBD_SerialManager
// Copyright (c) 2015 Alex Taujenis - MIT License
//
// Modified Mar-10-2022 by TEB. 
// Replace the RBD_SerialManager.cpp and RBD_SerialManager.h files in the library if Serial-1 Port is needed.
// Be sure to change the baud rate (line 15) to match your host's requirements.
// 

#ifndef RBD_SERIAL_MANAGER
#define RBD_SERIAL_MANAGER

#include <Arduino.h>

namespace RBD {
  class SerialManager {
    public:
      SerialManager();
      void start();
      void setFlag(char value);
      void setDelimiter(char value);
      bool onReceive();
      String getValue();
      String getCmd();
      String getParam();
      bool isCmd(String value);
      bool isParam(String value);
      template <typename T> void print(T value){Serial1.print(value);}
      template <typename T> void println(T value){Serial1.println(value);}
    private:
      int _position;
      char _char;
      char _flag      = '\n'; // you must set the serial monitor to include a newline with each command
      char _delimiter = ',';
      String _buffer  = "";
      String _value   = "";
  };
}

#endif