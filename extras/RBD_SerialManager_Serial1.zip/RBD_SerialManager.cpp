// Arduino RBD Serial Manager Library v1.0.0 - A simple interface for serial communication.
// https://github.com/alextaujenis/RBD_SerialManager
// Copyright (c) 2015 Alex Taujenis - MIT License
// Modified Mar-10-2022 by TEB. 
// Replace the RBD_SerialManager.cpp and RBD_SerialManager.h files in the library if Serial-1 Port is needed.
// Be sure to change the baud rate (line 15) to match your host's requirements.
// 
#include <Arduino.h>
#include <RBD_SerialManager.h> // https://github.com/alextaujenis/RBD_SerialManager

namespace RBD {
  SerialManager::SerialManager() {}

  void SerialManager::start() {
    Serial1.begin(115200, SERIAL_8N1, 34, 32); // Alternate Port, Serial-1.
//    Serial.begin(115200);
  }

  bool SerialManager::onReceive() {
    if(Serial1.available()) {
      _char = char(Serial1.read());

      if(_char == _flag) {
        _value  = _buffer;
        _buffer = "";
        return true;
      }
      else {
        _buffer += _char;
        return false;
      }
    }
    else {
      return false;
    }
  }

  String SerialManager::getValue() {
    return _value;
  }

  void SerialManager::setFlag(char value) {
    _flag = value;
  }

  void SerialManager::setDelimiter(char value) {
    _delimiter = value;
  }

  String SerialManager::getCmd() {
    _position = getValue().indexOf(_delimiter);

    if(_position > -1) {
      return _value.substring(0, _position);
    }
    else {
      return getValue();
    }
  }

  String SerialManager::getParam() {
    _position = getValue().indexOf(_delimiter);

    if(_position > -1) {
      return _value.substring(_position + 1, _value.length());
    }
    else {
      return "";
    }
  }

  bool SerialManager::isCmd(String value) {
    return getCmd() == value;
  }

  bool SerialManager::isParam(String value) {
    return getParam() == value;
  }
}